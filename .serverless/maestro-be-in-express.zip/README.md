# nodemon index to run the app

# export <for mac> set <for windows> PORT=3000


https://sharp.pixelplumbing.com/install