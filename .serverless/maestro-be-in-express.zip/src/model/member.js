const member = {
  id: "",
  name: "",
};

module.exports = member;
